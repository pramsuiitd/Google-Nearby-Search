import a3,pickle,time
print("Starting Checker")
f=open("testcase.bin","rb")
l=pickle.load(f)
check=[]
st=time.time()
for i in l:
    z,q=i[0],i[1]
    a=a3.PointDatabase(z)
    for i in q:
        check.append(a.searchNearby(i[0],i[1]))
print(time.time()-st)
if check==pickle.load(open("check.bin","rb")):
    print("Yay")
else:
    print("Nay")